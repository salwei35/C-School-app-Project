﻿//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Runtime.InteropServices.WindowsRuntime;
//using Windows.Foundation;
//using Windows.Foundation.Collections;
//using Windows.UI.Xaml;
//using Windows.UI.Xaml.Controls;
//using Windows.UI.Xaml.Controls.Primitives;
//using Windows.UI.Xaml.Data;
//using Windows.UI.Xaml.Input;
//using Windows.UI.Xaml.Media;
//using Windows.UI.Xaml.Navigation;
//using Microsoft.WindowsAzure.MobileServices;
//using System.Threading.Tasks;
//using Windows.UI.Popups;
//using Windows.Storage;
//using System.Net.Http;
//using Newtonsoft.Json;


//// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

//namespace App1
//{
//    public sealed partial class FoodInventory : UserControl
//    {
//        private readonly ModelsContext _contex = new ModelsContext();
//        //private readonly object txtName;
//        //private object txtStock;

//        internal FoodInventory(ModelsContext contex)
//        {
//            this.InitializeComponent();
//            _contex = contex;
//        }

//        private void InitializeComponent()
//        {
//            throw new NotImplementedException();
//        }

//        private void btnAdd_Click(object sender, RoutedEventArgs e)
//        {
//            // PB TODO: Fix these calls
//            Food lcl_Food = new Food();
//            lcl_Food.Name = txtName.ToString();
//            //lcl_Food.price = Convert.ToInt32(txtPrice.Text);
//            lcl_Food.Stock = Convert.ToInt32(txtStock.ToString());
//            //_contex.Add(lcl_Food);
//            //_contex.SaveChangesAsync();
//        }
//    }

//    internal class Food
//    {
//        public object Name;
//        public int Stock { get; internal set; }
//        public int price { get; internal set; }

//        public Food()
//        {
//        }

//    }
//}
////var firstNotSecond = list1.Except(list2).ToList();
////var secondNotFirst = list2.Except(list1).ToList();