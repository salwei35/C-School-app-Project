﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Popups;
using System.Threading.Tasks;
using System.Diagnostics;
using Microsoft.WindowsAzure.MobileServices;
using System.Threading.Tasks;
using Windows.UI.Popups;
using Windows.Storage;
using System.Net.Http;
using Newtonsoft.Json;


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
      

        public MainPage()
        {

            this.InitializeComponent();
            txtBoxRas.Text = "Rasmussen College";
            txtBoxRas.FontSize = 14;
            txtBoxRas.Foreground = new SolidColorBrush(Windows.UI.Colors.Red);
            
            BL_PageContent.CreatedBy = "Created By: Jared Salwei";
            txtBoxFooter.Text = BL_PageContent.CreatedBy;


            BL_PageContent.GetPicURL = "http://www.rasmussen.edu/images/logo-internal.png";
            Uri uriImg = new Uri(BL_PageContent.GetPicURL);
            Windows.UI.Xaml.Media.Imaging.BitmapImage imgBitMap = new
            Windows.UI.Xaml.Media.Imaging.BitmapImage();
            imgBitMap.UriSource = uriImg;
            imgLogo.Source = imgBitMap;

           

        }
        IMobileServiceTable<TodoItem> todoTable = App.MobileService.GetTable<TodoItem>();
        MobileServiceCollection<TodoItem, TodoItem> items;

        public class Contact
        {
            public int ID { get; set; }
            public string NAME { get; set; }
            public string EMAILADDRESS { get; set; }
        }


        public class TodoItem
        {
            public string Id { get; set; }
            public string Text { get; set; }
            public bool Complete { get; set; }
        }

        async private void Submit_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                TodoItem item = new TodoItem
                {
                    Text = txtBoxItem.Text,
                    Complete = false
                };
                await App.MobileService.GetTable<TodoItem>().InsertAsync(item);
                var dialog = new MessageDialog("Successful!");
                await dialog.ShowAsync();
            }
            catch (Exception em)
            {
                var dialog = new MessageDialog("An Error Occured: " + em.Message);
                await dialog.ShowAsync();
            }
        }

        public void GetDBSync()
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new
                    Uri("https://cis4655c-webapp1.azurewebsites.net");

                var json = client.GetStringAsync("/").Result;
                var contacts = JsonConvert.DeserializeObject<Contact[]>(json);
            }
        }


        private async Task RefreshTodoItems()
        {
            MobileServiceInvalidOperationException exception = null;
            try
            {
                // This code refreshes the entries in the list view by querying the TodoItems table.
                // The query excludes completed TodoItems
                items = await todoTable
                    .Where(TodoItem => TodoItem.Complete == false)
                    .ToCollectionAsync();
            }
            catch (MobileServiceInvalidOperationException e)
            {
                exception = e;
            }

            if (exception != null)
            {
                await new MessageDialog(exception.Message, "Error loading items").ShowAsync();
            }
            else
            {
                ListItems.ItemsSource = items;
                this.btnRefresh.IsEnabled = true;
            }
        }

        private async void CheckBoxComplete_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox cb = (CheckBox)sender;
            TodoItem item = cb.DataContext as TodoItem;
            await UpdateCheckedTodoItem(item);
        }

        private async Task UpdateCheckedTodoItem(TodoItem item)
        {
            // This code takes a freshly completed TodoItem and updates the database. When the MobileService 
            // responds, the item is removed from the list 
            await todoTable.UpdateAsync(item);
            items.Remove(item);
            ListItems.Focus(Windows.UI.Xaml.FocusState.Unfocused);

            //await SyncAsync(); // offline sync
        }

        async private void btnRefresh_Click_1(object sender, RoutedEventArgs e)
        {
            await RefreshTodoItems();
        }



        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            ProcessCalc();
        }

        private void ProcessCalc()
        {
            Int32 Var1 = Convert.ToInt32(txtBoxInput1.Text) + Convert.ToInt32(txtBoxInput2.Text);
            txtBoxDisplay.Text = Convert.ToString(Var1);
        }

        async private void btnCourse1_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource1();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse2_Click(object sender, RoutedEventArgs e)
        {

            BL_PageContent.Cource2();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse3_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource3();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse4_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource4();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse5_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource5();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse6_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource6();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse7_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource7();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse8_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource8();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse9_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource9();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse10_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource10();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse11_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource11();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse12_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource12();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse13_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource13();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }

        async private void btnCourse14_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Cource14();
            txtBoxCourse.Text = BL_PageContent.VarOutput;
            var dialog = new MessageDialog(BL_PageContent.VarOutput);
            await dialog.ShowAsync();
        }


 

        private void HyperlinkButton_Click_1(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(UserAuth));
        }

        private void HyperlinkButton6_Click(object sender, RoutedEventArgs e)
        {

        }

      

        private void button22_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(GoogleAuth));
        
        }
        private void button23_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(FoodInventory));
        }

    }



}
