﻿using Windows.UI.Xaml.Media.Imaging;

namespace App1
{
    public class image
    {
        public BitmapImage Source { get; internal set; }
    }
}