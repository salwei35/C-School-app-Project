﻿namespace System
{
    internal class Console
    {
    }
}