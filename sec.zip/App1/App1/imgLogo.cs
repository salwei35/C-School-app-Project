﻿using Windows.UI.Xaml.Media.Imaging;

namespace App1
{
    internal class imgLogo
    {
        public static BitmapImage Source { get; internal set; }
    }
}