﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App1
{
    class Food
    {
        public string Name { get; set; }
        public int Stock { get; set; }
        public Decimal Price { get; set; }

        public Food(string name, int stock, Decimal price)
        {
            this.Name = name;
            this.Stock = stock;
            this.Price = price;
        }

        public string ToString(int? id)
        {
            StringBuilder retval = new StringBuilder();
            if (id.HasValue)
                retval.Append("ID: " + id.Value.ToString() + "\t");
            retval.Append(this.Name + ":\t");
            retval.Append(this.Stock.ToString() + " in stock\t");
            retval.Append(this.Price.ToString() + " each\t");
            retval.Append(Environment.NewLine);

            return retval.ToString();
        }
    }
}
