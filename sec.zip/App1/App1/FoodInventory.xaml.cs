﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Text;
using Windows.UI.Popups;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace App1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class FoodInventory : Page
    {
        private IList<Food> Inventory;

        public FoodInventory()
        {
            this.InitializeComponent();
            Inventory = new List<Food>();
            txtSearchResults.IsReadOnly = true;
            txtNewName.IsEnabled = false;
            txtNewPrice.IsEnabled = false;
            txtNewStock.IsEnabled = false;
            rbxSearchByName.IsChecked = true;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateInputs())
                return;

            string name = txtName.Text;

            if (Inventory
                .Where(i => i.Name.ToUpper()
                .Equals(name.ToUpper()))
                .Count() != 0)
            {
                ShowError("Item by that name already exists", "Add");
                return;
            }

            int stock = Int32.Parse(txtStock.Text);
            Decimal price = Decimal.Parse(txtPrice.Text);

            Inventory.Add(new Food(name, stock, price));
            UpdateInventory();
        }

        private bool ValidateInputs()
        {
            int testInt;
            if (!Int32.TryParse(txtStock.Text, out testInt))
            {
                ShowError("Stock amount invalid: must be a whole number", "Add");
                return false;
            }

            Double testDouble;
            if (!Double.TryParse(txtPrice.Text, out testDouble))
            {
                ShowError("Price invalid", "Add");
                return false;
            }
            return true;
        }

        private void UpdateInventory()
        {
            StringBuilder newText = new StringBuilder();
            newText.Append("In Inventory:" + Environment.NewLine);

            for (int i = 0; i < Inventory.Count; i++)
            {
                newText.Append(Inventory[i].ToString(i));
            }

            tbkInventory.Text = newText.ToString();
            txtSearchResults.Text = "Compare items";
            txtSearch.Text = "Items you want to compare enter here:";
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder newText = new StringBuilder();
            string searchString = txtSearch.Text.ToUpper();
            if (String.IsNullOrEmpty(searchString))
            {
                txtSearchResults.Text = "Compare items";
                return;
            }

            newText.Append("Compare items" + Environment.NewLine);

            var searchResults = Inventory.Where(
                i => i.Name.ToUpper().Contains(searchString)).ToList();

            for (int i = 0; i < searchResults.Count; i++)
            {
                newText.Append(searchResults[i].ToString(i));
            }

            txtSearchResults.Text = newText.ToString();
        }

        private void txtSearch_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtSearch.Text.Equals("Items you want to compare enter here:"))
                txtSearch.Text = string.Empty;
        }

        private void btnDeleteItem_Click(object sender, RoutedEventArgs e)
        {
            int id;
            if (!Int32.TryParse(txtDeleteItem.Text,out id))
            {
                ShowError("Value is not numeric", "Delete");
                return;
            }

            if (id < 0 || id >= Inventory.Count)
            {
                ShowError("No item exists with that ID", "Delete");
                return;
            }

            Inventory.RemoveAt(id);
            UpdateInventory();
            txtSearchResults.Text = "Compare items";
            txtSearch.Text = "Items you want to compare enter here:";
            txtDeleteItem.Text = string.Empty;
        }

        private async void ShowError(string message, string title)
        {
            MessageDialog dialog = new MessageDialog(message, title);
            await dialog.ShowAsync();
        }

        private void chkUseNewName_Click(object sender, RoutedEventArgs e)
        {
            txtNewName.IsEnabled = chkUseNewName.IsChecked.Value;
        }

        private void chkUseNewPrice_Click(object sender, RoutedEventArgs e)
        {
            txtNewPrice.IsEnabled = chkUseNewPrice.IsChecked.Value;
        }

        private void chkUseNewStock_Click(object sender, RoutedEventArgs e)
        {
            txtNewStock.IsEnabled = chkUseNewStock.IsChecked.Value;
        }

        private void btnUpdateItem_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateUpdateControls())
                return;

            int updateItemID = -1;

            if (rbxSearchByName.IsChecked.Value)
            {
                var item = Inventory
                    .Where(i => i.Name.ToUpper()
                    .Equals(txtUpdateQuery.Text.ToUpper()))
                    .FirstOrDefault();

                updateItemID = Inventory.IndexOf((Food)item);
            }
            else if (rbxSearchByID.IsChecked.Value)
            {
                updateItemID = Int32.Parse(txtUpdateQuery.Text);
            }

            if (updateItemID == -1)
            {
                ShowError("Item could notbe found", "Update");
                return;
            }

            if (txtNewName.IsEnabled)
            {
                Inventory[updateItemID].Name = txtNewName.Text;
            }
            if (txtNewPrice.IsEnabled)
            {
                Inventory[updateItemID].Price = decimal.Parse(txtNewPrice.Text);
            }
            if (txtNewStock.IsEnabled)
            {
                Inventory[updateItemID].Stock = Int32.Parse(txtNewStock.Text);
            }

            UpdateInventory();
        }

        private bool ValidateUpdateControls()
        {
            int testInt;
            if (rbxSearchByID.IsChecked.Value)
            {
                if (!Int32.TryParse(txtUpdateQuery.Text, out testInt))
                {
                    ShowError("Update ID invalid: must be numeric", "Update");
                    return false;
                }
                else if (testInt < 0 || testInt >= Inventory.Count)
                {
                    ShowError("No item exists by that ID", "Update");
                    return false;
                }
            }

            decimal testDecimal;
            if (txtNewPrice.IsEnabled)
            {
                if (!decimal.TryParse(txtNewPrice.Text, out testDecimal))
                {
                    ShowError("Update price invalid", "Update");
                    return false;
                }
            }

            if (txtNewStock.IsEnabled)
            {
                if (!Int32.TryParse(txtNewStock.Text, out testInt))
                {
                    ShowError("Update stock invalid: must be a whole number", "Update");
                    return false;
                }
            }

            return true;
        }
    }
}
