﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Popups;
using System.Threading.Tasks;


namespace App1
{
   public class BL_PageContent


    {
        internal static string GetPicURL;

        public static string VarOutput { get; set; }
        public static string CreatedBy { get; set; }

        public static void Cource1()
        {
            VarOutput = "";
            string[] names = new string[3] { "COP3488C", "UWP1", "This course is mobile app development." };
            
            for (int i = 0; i < names.Length; i++)
            {
                
                VarOutput = VarOutput + names[i] + "  ";
               
            }


        }
        public static void Cource2()
        {
            VarOutput = "";
            string[] names = new string[3] { "DOP3488B,", "UWC1,", "This course is Cloud Computing." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource3()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP3589,", "UWP2,", "This course Computer Programming Java 1." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource4()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP3599,", "UWP3,", "This course Computer Programming Java 2." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource5()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP3514,", "UWP3,", "This course Computer Programming Java 3." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource6()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP389,", "UWP2,", "This course SQL 1." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource7()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP3987,", "UWP2,", "This course SQL 2." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource8()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP3549,", "UWP3,", "This course .net 1." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource9()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP4587,", "UWP2,", "This course .net 2." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource10()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP3589,", "UWP2,", "This course is Css 1." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource11()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP3589,", "UWP2,", "This course is css 2." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource12()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP3589,", "UWP2,", "This course is math 1." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource13()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP3589,", "UWP2,", "This course is math 2." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

        public static void Cource14()
        {
            VarOutput = "";
            string[] names = new string[3] { "BOP3589,", "UWP2,", "This course is the capstone ." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "  ";
            }

        }

    }


}




