﻿using System;

namespace App1
{
    internal class ModelsContext
    {
        public ModelsContext()
        {
        }

        internal void SaveChangesAsync()
        {
            throw new NotImplementedException();
        }
    }
}